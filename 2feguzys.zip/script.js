//JavaScript
function quiz() {
    var score = 0;
    var totalQuestions = 8;
    alert("Time To Prove Yourself");
    alert("Make sure you answer all the questions... Each one correctly or you fail the whole thing (I suggest that you read the books and watch the movies: TVD, Twilight, and Maze Runner).");

    var q1 = prompt("Who is the pigme girl of Mystic Falls, Virginia? (Both First and Last name.)");
    if (q1 == "Elena Gilbert") {
        score = score + 1;
        alert("Correct");

    } else {
        alert("Incorrect");

    }

    var q2 = prompt("Who is the pigme girl of Forks, Washington? (Both First and Last name.)");
    if (q2 == "Bella Swan") {
        score = score + 1;
        alert("Correct");

    } else {
        alert("Incorrect");

    }

    var q3 = prompt("Who is the pigme girl of the glade? (Both First and Last name.)");
    if (q3 == "Teresa Agnes") {
        score = score + 1;
        alert("Correct");

    } else {
        alert("Incorrect");

    }
    
    alert("Congrats you made it through level 1. But don't worry, there are many more bad things coming.");
    
    alert("Level 2 - The Maze Runner");
   
    var q4 = prompt("What are the creatures in the maze called?");
    if (q4 == "Greavers") {
        score = score + 1;
        alert("Correct");

    } else {
        alert("Incorrect");

    }
    
    var q5 = prompt("Who is the Keeper of the Runners?");
    if (q5 == "Minho") { 
        score = score + 1;
        alert("Correct");
    
    } else { 
    alert("Incorrect");
        
    }
    
    var q6 = prompt("Who came out of the box the day before Teresa? (Only first name)");
    if (q6 == "Thomas") { 
        score = score + 1;
        alert("Correct");
        
    } else {
    alert("Incorrect");
    
    }
    
    var q7 = prompt("What is the organization called that sent all the kids to the glade?");
    if (q7 == "WICKED") { 
        score = score + 1;
        alert("Correct");
        
    } else {
    alert("Incorrect");
        
    }
    
    var q8 = prompt("Who is the leader of the glade? (First name only)");
    if (q8 == "Alby") { 
        score = score + 1
        alert("Correct");
    
    } else {  
    alert("Incorrect");

    }

    var 
        
    alert("You got " + score + " questions out of " + totalQuestions + " correct.");
}